<?php


namespace Basic\Module\Model;

/**
 * Class ForTest
 *
 * @package Basic\Module\Model
 */
class ForTest
{
    public function getContent()
    {

        $html = "<br> For Test Plugin Working !<br>";
        return $html;
        
    }
}