<?php


namespace Basic\Module\Model;

use Magento\Catalog\Api\Data\ProductInterface;

/**
 * Class ProductKey
 *
 * @package Basic\Module\Model
 */
class ProductKey
{
    public function getKey(ProductInterface $product, string $prefix = 'Item'): string
    {
        return sprintf('%s : %s', $prefix, $product->getSku());
    }
}